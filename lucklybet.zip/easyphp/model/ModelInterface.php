<?php

/**
 *
 */
interface ModelInterface {
	
	/**
	 * 
	 */
	public function getModelName();
	
	
	public function getDataArray();
}

?>