<?php


return array(
	'default'=>'defaults',
	'values'=>'values',
	'foreach'=>'loop',
	'loop'=>'loop',
	'test'=>'test',
	'if'=>'testif',
	'elseif'=>'testelse',
	'else'=>'testelse',
	'lang'=>'lang',
	'php'=>'php',
	'run'=>'run',
	'tpl'=>'tpl',
	'gtpl'=>'gtpl',
	'url'=>'url',
	'param'=>'param',
	'template'=>'tpl',
	'config'=>'config',
	'cfg'=>'config',
	'session'=>'session',
	'request'=>'request',
	'cookie'=>'cookie',
	'html'=>'html',
	'date'=>'date',
    'for'=>'testfor',
	'res'=>'res',
	'cut'=>'cut'
);