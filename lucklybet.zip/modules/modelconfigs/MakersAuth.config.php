<?php

/**
 * 庄家认证
 * @author blueyb.java@gmail.com
 */

return array(
	'orm' => array(
		'table' => 'yyx_makers_auth',
		'pk' => 'id',
		'map' => array(
		)
	),
	'rule' => array(
		
	)
);