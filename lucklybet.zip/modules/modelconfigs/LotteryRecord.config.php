<?php

/**
 * 抽奖记录配置
 * @author blueyb.java@gmail.com
 */

return array(
	'orm' => array(
		'table' => 'yyx_lottery_record',
		'pk' => 'id'
	),
	'rule' => array()
);