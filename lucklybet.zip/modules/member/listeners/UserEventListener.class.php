<?php
/**
 * 用户事件监听
 * @author blueyb.java@gmail.com
 */
class UserEventListener implements IUserEventListener{
	/*
	 * @see IUserEventListener::login()
	 */
	public function login(User $user){
		// TODO Auto-generated method stub
	}
	
	/*
	 * @see IUserEventListener::logout()
	 */
	public function logout(User $user){
		// TODO Auto-generated method stub
	}
	
	/*
	 * @see IUserEventListener::register()
	 */
	public function register(User $user){
		// TODO Auto-generated method stub
	}
}
?>
