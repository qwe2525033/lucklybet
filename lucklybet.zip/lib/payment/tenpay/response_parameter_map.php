<?php
return array(
	//基本参数
	'sign_type'=>'payment_sign_type',
	'sign'=>'payment_sign',
	//业务参数
	'out_trade_no'=>'payment_out_trade_no',
	'pay_info'=>'payment_trade_message',
	'trade_state'=>'payment_trade_status',
	'subject'=>'payment_subject',
	'total_fee'=>'payment_total_fee',
	'discount'=>'payment_discount',
);
