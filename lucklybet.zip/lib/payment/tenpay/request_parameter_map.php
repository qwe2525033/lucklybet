<?php
return array(
	//基本参数
	'payment_charset'=>'input_charset',
	'payment_sign_type'=>'sign_type',
	'payment_asyn_url'=>'notify_url',
	'payment_sync_url'=>'return_url',
		
	//业务参数
	'payment_out_trade_no'=>'out_trade_no',
	'payment_subject'=>'body',
	'payment_total_fee'=>'total_fee',
	'payment_body'=>'subject',
	'payment_default_bank'=>'bank_type',
);