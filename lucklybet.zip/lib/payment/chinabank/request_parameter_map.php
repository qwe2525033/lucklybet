<?php
return array(
	//基本参数
	'payment_asyn_url'=>'v_url',
	'payment_sync_url'=>'v_url',
	//业务参数
	'payment_out_trade_no'=>'v_oid',
	'payment_total_fee'=>'v_amount',
);