<?php
return array(
	//基本参数
	'sign'=>'v_md5str',
	//业务参数
	'out_trade_no'=>'v_oid',
	'trade_status'=>'v_pstatus',
	'payment_trade_message'=>'v_pstring',
	'payment_pay_bank'=>'v_pmode',
	'total_fee'=>'v_amount',
	'payment_subject'=>'remark1',
	'body'=>'remark1',
);
