<?php
return array(
	//基本参数
	'payment_asyn_url'=>'pageUrl',
	'payment_sync_url'=>'bgUrl',
		
	//业务参数
	'payment_out_trade_no'=>'orderId',
	'payment_subject'=>'productName',
	'payment_total_fee'=>'orderAmount',
	'payment_body'=>'productDesc',
);