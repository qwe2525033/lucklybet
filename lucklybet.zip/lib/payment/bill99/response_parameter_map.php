<?php
return array(
	//基本参数
	'signType'=>'payment_sign_type',
	'signMsg'=>'payment_sign',
	//业务参数
	'orderId'=>'payment_out_trade_no',
	'payResult'=>'payment_trade_status',
	'payAmount'=>'payment_total_fee',
);
