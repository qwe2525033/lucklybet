<?php

/**
 * 支付接口所支持的类型,数组中的key为类型名,value为别名
 */
return array(
	'alipay'=>'支付宝',
	'alipaybank'=>'支付宝网银',
	'chinabank'=>'网银在线',
	'tenpay'=>'财付通',
	'bill99'=>'快钱',
);