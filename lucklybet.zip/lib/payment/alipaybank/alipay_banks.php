<?php
//支付宝所绑定的网银
$alipayBanks = array();
$alipayBanks['icbcb2c'] = '中国工商银行';
$alipayBanks['cmb'] = '招商银行';
$alipayBanks['ccb'] = '中国建设银行';
$alipayBanks['boc101'] = '中国银行';
$alipayBanks['abc'] = '中国农业银行';
$alipayBanks['comm'] = '交通银行';
$alipayBanks['spdb101'] = '上海浦东发展银行';
$alipayBanks['gdb'] = '广东发展银行';
$alipayBanks['citic'] = '中信银行';
$alipayBanks['ceb101'] = '光大银行';
$alipayBanks['cib'] = '兴业银行';
$alipayBanks['sdb'] = '深圳发展银行';
$alipayBanks['cmbc'] = '中国民生银行';
$alipayBanks['shbank101'] = '上海银行';
$alipayBanks['spabank'] = '平安银行';

return $alipayBanks;