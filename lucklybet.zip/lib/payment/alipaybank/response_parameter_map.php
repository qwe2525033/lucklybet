<?php
return array(
	//基本参数
	'sign_type'=>'payment_sign_type',
	'sign'=>'payment_sign',
	//业务参数
	'out_trade_no'=>'payment_out_trade_no',
	'payment_type'=>'payment_payment_type',
	'trade_no'=>'payment_trade_no',
	'trade_status'=>'payment_trade_status',
	'subject'=>'payment_subject',
	'price'=>'payment_price',
	'quantity'=>'payment_quantity',
	'total_fee'=>'payment_total_fee',
	'body'=>'payment_body',
	'discount'=>'payment_discount',
);
