<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '3800600390' );
define( "WB_SKEY" , '1b6717f1b56581b2b1af45d498619e42' );
define( "WB_CALLBACK_URL" , 'http://116.255.199.140:8000/lib/weibo/sina/callback.php' );
